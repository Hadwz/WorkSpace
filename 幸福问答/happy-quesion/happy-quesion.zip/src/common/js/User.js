

export default class User {
	constructor({uname,user_id}){
		this.uname = uname;
		this.userId = user_id;
		this.photo = 'static/images/headimg.png';
	}

}