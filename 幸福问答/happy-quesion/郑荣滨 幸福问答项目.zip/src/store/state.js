/*
 * @Author: Hadwz 
 * @Date: 2017-11-15 22:57:43 
 * @Last Modified by: Hadwz
 * @Last Modified time: 2017-11-25 17:39:24
 */


const state = {

	//账户
	user:{
		isVip:false,
		duration:'',
		startTime:'',
		endTime:'',
	},

	//问题
	question:{
		id:''
	},

	//expert
	expert:{
		
	},

	modalActive: false


}

export default state;