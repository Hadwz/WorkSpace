<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang="less">
	body{
    background-image: url('assets/bg_img.jpg');
    background-size: 100%;
	}
</style>
