<template>
	<section class="not-found">
	</section>	
</template>

<script>
export default {
	
}
</script>

<style lang="less" scoped>

	.not-found {
		height: 1000px;
		width: 100%;
		background: url('../assets/404.jpg') no-repeat center center;
		background-size: 100%;
	}
</style>
